			# This code was produced by the CERI Compiler
	.data
	.align 8
x:	.quad 0
y:	.quad 0
	.text		# The following lines contain the program
	.globl main	# The main function must be visible from outside
main:			# The main function body :
	movq %rsp, %rbp	# Save the position of the stack's top
	push $5
	pop x
	push $10
	pop y
Keyword detected: IF
	push x
	push y
	pop %rax
	pop %rbx
	cmpq %rax, %rbx
	jb Vrai2	# If below
	push $0		# False
	jmp Suite2
Vrai2:	push $0xFFFFFFFFFFFFFFFF		# True
Suite2:
	pop %rax
	cmpq $0, %rax
	je ELSE0	# Sauter à ELSE si la condition est fausse
