[x, y]

x := 5;
y := 10;

IF x < y THEN
    x := x + 1;
ELSE
    y := y - 1.