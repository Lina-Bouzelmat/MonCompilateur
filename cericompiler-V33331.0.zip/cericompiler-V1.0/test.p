[a]
a := 0;
WHILE (a < 3) DO a := a + 1.
