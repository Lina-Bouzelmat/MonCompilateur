// tokeniser.h : shared definition for tokeniser.l and compilateur.cpp

enum TOKEN {FEOF, UNKNOWN, STRINGCONST, CHARCONST, NUMBER, ID, RBRACKET, LBRACKET, RPARENT, LPARENT, COMMA, 
COLON, SEMICOLON, DOT, ADDOP, MULOP, RELOP, NOT, ASSIGN, KEYWORD};

